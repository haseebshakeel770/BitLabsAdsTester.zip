# BitLabs Ads Tester

Real Android test app for the **official BitLabs SDK** (`com.prodege.bitlabs:core:5.1.0`) plus a small Node.js backend that receives and verifies BitLabs **Reward & Reconciliation** callbacks.

> **Build status: NOT tested by the author.** The backend logic was tested (unit tests + local end-to-end). The Android project was written against the BitLabs docs but has **not been compiled** (no Gradle/Android SDK/network in the authoring environment). Your first GitHub Actions run is the first real build. See Troubleshooting if it fails.

## Credentials: what goes where

| Value | Where | In APK/GitHub? |
|---|---|---|
| **App/API Token** (Dashboard → Apps → your app → Integration) | In-app *Configuration* field, or `bitlabs.local.properties` | Client-side value; keep it out of GitHub anyway |
| **Secret Key / S2S key** | Backend env var `BITLABS_SECRET_KEY` only | **Never** |
| Unity Ads Game ID `6225197` | Not used here. It is **not** a BitLabs token | No |

Nothing is hardcoded or auto-retrieved. With no token the app shows **Missing** and refuses to launch.

## Build the APK with GitHub (no Gradle wrapper needed)

1. Unzip this ZIP on your computer.
2. Create a new GitHub repository (private is fine).
3. Upload the **contents** of the unzipped folder (not the ZIP itself) so `settings.gradle.kts`, `app/`, `backend/`, `.github/` are at the repo root. GitHub's web uploader can skip hidden folders: if `.github/workflows/build.yml` is missing in the repo, use **Add file → Create new file**, type `.github/workflows/build.yml` as the name, and paste the file's contents.
4. Open **Actions** → *Build debug APK* → **Run workflow** (it also runs on every push to `main`/`master`).
5. When it finishes green, open the run → **Artifacts** → download `BitLabsAdsTester-debug-apk` → unzip → install `app-debug.apk` (allow "install unknown apps").

Local build (optional): Android Studio → Open this folder → Run. Or with Gradle 8.7+: `gradle assembleDebug`.

## Using the app

1. Open **Configuration**, paste your App/API Token, optionally your backend URL (`https://…`), tap **Save**.
2. **Initialize SDK**, then **Open BitLabs Offerwall**.
3. **Open Offers / Games / Surveys** open the same offerwall with the documented `display_mode` option (`offers`, `gaming`, `surveys`). Games and Offers only appear if enabled for your placement in the Dashboard; the app never creates fake offers.
4. **Check survey availability** calls `BitLabs.API.checkSurveys` (a real SDK call).
5. **Transaction history** reads your backend's ledger (verified callbacks only). **Demo Coins** are a local counter that nothing credits; they are never mixed with verified rewards.
6. **Test Mode** is a Dashboard setting (Apps → your app → Surveys → Test Mode). The app can't read it and never claims it is enabled.

## Backend (callbacks)

Based on BitLabs docs: Reward & Reconciliation callbacks, Securing callbacks through hashing, Callback parameters.

- Verification: BitLabs appends `&hash=` (HEX **SHA1 HMAC** of the whole URL without the hash, keyed with your app's secret). The server hashes the exact received URL and compares in constant time. Unit test reproduces the example from the BitLabs docs.
- Duplicates: `tx` is unique; a repeated `tx` is acknowledged but never credits twice.
- Reconciliation: `type=RECONCILIATION` + `ref` marks the original reversed; a **negative** `val` is applied to the balance. If `val` is not negative the original is marked reversed but the balance is left alone and flagged for manual review (BitLabs docs say reconciliation values can be negative, positive or 0).
- Unknown types are stored, not credited. Invalid hash → HTTP 403. Missing key → 500.

### Run locally
```
cd backend
cp ../.env.example .env      # then export the variables (or use your host's env UI)
npm test
BITLABS_SECRET_KEY=... PUBLIC_BASE_URL=http://localhost:3000 ENABLE_TEST_ENDPOINTS=true node server.js
curl "http://localhost:3000/test/signed-url?uid=u1&tx=T1&val=100"   # returns a signed URL
curl "<that url>"                                                    # -> OK; again -> OK (duplicate ignored)
```
Leave `ENABLE_TEST_ENDPOINTS=false` in production.

### Deploy (any Node 18+ host with HTTPS: Render, Railway, Fly.io, a VPS behind Caddy/nginx…)
1. Deploy the `backend/` folder; start command `npm start`.
2. Set env vars: `BITLABS_SECRET_KEY`, `PUBLIC_BASE_URL` (exact `https://your-host`, no trailing slash), optional `DATA_FILE`.
3. Open `https://your-host/health`: expect `"secretConfigured": true`.
4. **Persistence:** the ledger is a JSON file. Free hosts often wipe local disk on redeploy; attach a persistent disk and point `DATA_FILE` at it, or swap in a database for anything beyond testing.
5. In the BitLabs Dashboard: **Apps → your app → Integration → Reward Callback** → cog wheel:
   - Callback URL Host: `https://your-host/callback`
   - Parameters (these query names are what the server reads; you choose them in the Dashboard): `uid` = `[%USER:UID%]`, `tx` = `[%TX%]`, `val` = `[%VALUE:CURRENCY%]`, `raw` = `[%VALUE:USD%]`, `ref` = `[%REF%]`, `type` = `[%ACTIVITY:TYPE%]`
   - Save, then **Save Changes**.
6. Use the Dashboard **Callback Tester** (docs: Testing callbacks) against that URL. Callbacks do **not** work until steps 1–5 are done. The tester's exact UI may differ from this guide; follow the BitLabs doc page.

`PUBLIC_BASE_URL` must match the host BitLabs actually calls, because the hash covers the full URL. 

### Privacy note
`GET /api/transactions?uid=` is unauthenticated and keyed by the random test user ID. Fine for a test app; add auth before using real user IDs.

## Troubleshooting

**Build fails: unresolved `ai.bitlabs.sdk.BitLabs`** – the import in `BitLabsGateway.kt` (`ai.bitlabs.sdk.BitLabs`) is my best match to the SDK's package and is unverified. Check the SDK's GitHub README/sources and fix that one import; all SDK calls live in that file.
**Build fails: dependency not found / metadata / minCompileSdk** – confirm `com.prodege.bitlabs:core:5.1.0` exists on Maven Central; if the AAR demands compileSdk 35 or newer AGP/Kotlin, raise those in `build.gradle.kts` (and Gradle in `build.yml`).
**`checkSurveys` signature errors** – the docs page shows `getSurveys` twice; `checkSurveys(onResponse, onError)` is taken from the SDK 4.0.0 release notes and the older docs. Adjust in `BitLabsGateway.kt` if needed.
**SDK shows Failed** – open the log; the exception class and message are shown (token redacted). Usual cause: empty/incorrect token.
**Token Missing** – paste the App/API Token (not Secret Key, not Unity Game ID) and Save.
**Offerwall opens but no offers/surveys** – normal for new placements, unsupported countries/devices, or disabled Games/Offers/Surveys in Dashboard. Enable them there.
**Backend "Not Configured"** – no URL saved. **"Unreachable"** – URL must be `https://`, server running, `/health` reachable from the phone's network.
**Callback 403 Invalid hash** – wrong `BITLABS_SECRET_KEY`, wrong `PUBLIC_BASE_URL` (host/scheme differs from what BitLabs calls), a proxy rewriting the URL, or `hash` not last in the URL.
**Callback 400** – callback URL lacks `uid`, `tx` or numeric `val`.
**Rewards missing in history** – check Dashboard callback config and server logs (`[callback] …` lines never print secrets).
**Network errors in offerwall** – check connectivity; some survey providers use HTTP, which Android blocks by default (BitLabs docs describe whitelisting via `network_security_config.xml`).
