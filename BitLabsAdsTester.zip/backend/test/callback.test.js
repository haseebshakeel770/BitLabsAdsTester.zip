'use strict';
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { verifyUrl, sign, signUrl } = require('../lib/hash');
const { Ledger } = require('../lib/ledger');
const { parseCallback, applyCallback } = require('../lib/process');

// Example taken from BitLabs docs "Securing callbacks through hashing"
const DOC_URL = 'https://publisher.com/complete?uid=8cc877ee-af19-488d-b28d-216fb866b996&val=500';
const DOC_SECRET = 'JLOIAUNMHFli7ZJOQVEzm98rzqnm9';
const DOC_HASH = 'dbcd6bb8ca677344592842a52b4fca9bec36cd4b';

test('hash matches the official BitLabs documentation example', () => {
  assert.strictEqual(sign(DOC_URL, DOC_SECRET), DOC_HASH);
  assert.ok(verifyUrl(DOC_URL + '&hash=' + DOC_HASH, DOC_SECRET));
});

test('tampered URL, wrong key, missing hash are rejected', () => {
  assert.ok(!verifyUrl(DOC_URL.replace('500', '900') + '&hash=' + DOC_HASH, DOC_SECRET));
  assert.ok(!verifyUrl(DOC_URL + '&hash=' + DOC_HASH, 'wrong'));
  assert.ok(!verifyUrl(DOC_URL, DOC_SECRET));
  assert.ok(!verifyUrl(DOC_URL + '&hash=' + DOC_HASH, ''));
});

function mk() { return new Ledger(path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'bl-')), 'l.json')); }
const q = (o) => new URLSearchParams(o);

test('credit, duplicate protection, reconciliation', () => {
  const l = mk();
  const c1 = parseCallback(q({ uid: 'u1', tx: 'T1', val: '500', type: 'COMPLETE' }));
  assert.strictEqual(applyCallback(l, c1).duplicate, false);
  assert.strictEqual(applyCallback(l, c1).duplicate, true);   // same tx never credits twice
  assert.strictEqual(l.balanceFor('u1'), 500);

  const rec = parseCallback(q({ uid: 'u1', tx: 'T2', val: '-500', ref: 'T1', type: 'RECONCILIATION' }));
  applyCallback(l, rec);
  assert.strictEqual(l.get('T1').status, 'reversed');
  assert.strictEqual(l.balanceFor('u1'), 0);
});

test('invalid input rejected; pending not credited', () => {
  assert.ok(parseCallback(q({ uid: 'u', val: '1' })).error);
  assert.ok(parseCallback(q({ uid: 'u', tx: 't', val: 'abc' })).error);
  const l = mk();
  applyCallback(l, parseCallback(q({ uid: 'u', tx: 'P1', val: '70', state: 'PENDING' })));
  assert.strictEqual(l.balanceFor('u'), 0);
  assert.strictEqual(l.get('P1').status, 'pending');
});

test('signUrl round-trips', () => {
  const base = 'https://x.example/callback?uid=a&tx=b&val=1';
  assert.ok(verifyUrl(signUrl(base, 's3cret'), 's3cret'));
});
