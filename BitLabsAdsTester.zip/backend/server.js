'use strict';
const http = require('http');
const path = require('path');
const { verifyUrl, signUrl } = require('./lib/hash');
const { Ledger } = require('./lib/ledger');
const { parseCallback, applyCallback } = require('./lib/process');

const PORT = Number(process.env.PORT || 3000);
const SECRET = process.env.BITLABS_SECRET_KEY || '';          // server-side only, never logged
const PUBLIC_BASE_URL = (process.env.PUBLIC_BASE_URL || '').replace(/\/+$/, '');
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, 'data', 'ledger.json');
const TEST_ENDPOINTS = process.env.ENABLE_TEST_ENDPOINTS === 'true';

const ledger = new Ledger(DATA_FILE);

function origin(req) {
  if (PUBLIC_BASE_URL) return PUBLIC_BASE_URL;
  const proto = (req.headers['x-forwarded-proto'] || 'http').split(',')[0].trim();
  return proto + '://' + req.headers.host;
}

function send(res, code, body, type) {
  const payload = typeof body === 'string' ? body : JSON.stringify(body);
  res.writeHead(code, { 'Content-Type': type || (typeof body === 'string' ? 'text/plain' : 'application/json') });
  res.end(payload);
}

const server = http.createServer((req, res) => {
  // req.url is the RAW path+query exactly as received (required for hash verification).
  const u = new URL(req.url, 'http://placeholder');
  const route = u.pathname;

  if (req.method !== 'GET') return send(res, 405, 'Method Not Allowed');

  if (route === '/health') {
    return send(res, 200, {
      ok: true,
      secretConfigured: SECRET.length > 0,
      publicBaseUrlConfigured: PUBLIC_BASE_URL.length > 0,
      testEndpointsEnabled: TEST_ENDPOINTS,
    });
  }

  if (route === '/callback') {
    if (!SECRET) return send(res, 500, 'Server not configured');
    const fullUrl = origin(req) + req.url;
    if (!verifyUrl(fullUrl, SECRET)) {
      console.warn('[callback] rejected: invalid or missing hash');
      return send(res, 403, 'Invalid hash');
    }
    const cb = parseCallback(u.searchParams);
    if (cb.error) {
      console.warn('[callback] rejected: ' + cb.error);
      return send(res, 400, cb.error);
    }
    try {
      const r = applyCallback(ledger, cb);
      console.log(`[callback] ${r.duplicate ? 'duplicate' : 'applied'} tx=${cb.tx} type=${cb.type}`);
      return send(res, 200, r.duplicate ? 'OK (duplicate ignored)' : 'OK');
    } catch (e) {
      console.error('[callback] processing error: ' + e.message);
      return send(res, 500, 'Processing error');
    }
  }

  if (route === '/api/transactions') {
    const uid = (u.searchParams.get('uid') || '').trim();
    if (!uid) return send(res, 400, { error: 'uid required' });
    return send(res, 200, {
      uid,
      verifiedBalance: String(ledger.balanceFor(uid)),
      transactions: ledger.listFor(uid).map((t) => ({
        tx: t.tx, status: t.status, type: t.type, val: String(t.val), receivedAt: t.receivedAt, note: t.note,
      })),
    });
  }

  // Local/testing helper: builds a correctly signed callback URL for YOUR origin, then you open it.
  if (route === '/test/signed-url' && TEST_ENDPOINTS) {
    if (!SECRET) return send(res, 500, 'Set BITLABS_SECRET_KEY first');
    const p = u.searchParams;
    const base = origin(req) + '/callback?' + new URLSearchParams({
      uid: p.get('uid') || 'test-user', tx: p.get('tx') || 'tx-' + Date.now(), val: p.get('val') || '100',
      raw: p.get('raw') || '0.10', ref: p.get('ref') || '', type: p.get('type') || 'COMPLETE',
    }).toString();
    return send(res, 200, { url: signUrl(base, SECRET) });
  }

  return send(res, 404, 'Not found');
});

server.listen(PORT, () => {
  console.log(`BitLabs callback backend on :${PORT} | secret ${SECRET ? 'set' : 'MISSING'} | base ${PUBLIC_BASE_URL || '(from request)'}`);
});
