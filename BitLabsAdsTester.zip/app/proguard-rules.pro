# keep rules (release builds are not minified in this test app)
