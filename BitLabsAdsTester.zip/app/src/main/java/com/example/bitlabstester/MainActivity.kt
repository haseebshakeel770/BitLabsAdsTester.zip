package com.example.bitlabstester

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF4C8DFF)
private val Card = Color(0xFF111A2E)
private val Bg = Color(0xFF0B1220)
private val Good = Color(0xFF4CD08A)
private val Bad = Color(0xFFFF6B6B)
private val Warn = Color(0xFFFFC857)

class MainActivity : ComponentActivity() {
    private lateinit var state: AppState

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        state = AppState(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Blue, onPrimary = Color.White,
                    background = Bg, surface = Card, onSurface = Color(0xFFE6ECFF), onBackground = Color(0xFFE6ECFF)
                )
            ) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    var screen by remember { mutableStateOf("main") }
                    BackHandler(enabled = screen != "main") { screen = "main" }
                    when (screen) {
                        "tx" -> TransactionsScreen(state) { screen = "main" }
                        else -> MainScreen(state, onActivity = this@MainActivity) { screen = it }
                    }
                }
            }
        }
    }
}

@Composable
private fun statusColor(v: String): Color = when {
    v in listOf("Configured", "Initialized", "Ready", "Connected", "Available") -> Good
    v in listOf("Missing", "Failed", "Unreachable / not ready", "Error") -> Bad
    else -> Warn
}

@Composable
private fun StatusRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 13.sp, color = Color(0xFF9FB0D6))
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = statusColor(value))
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Card, RoundedCornerShape(14.dp)).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Blue)
        content()
    }
}

@Composable
private fun MainScreen(s: AppState, onActivity: MainActivity, go: (String) -> Unit) {
    var token by remember { mutableStateOf(s.token) }
    var backend by remember { mutableStateOf(s.backendUrl) }

    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column {
            Text("BitLabs Ads Tester", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Real Android Integration Test", fontSize = 13.sp, color = Color(0xFF9FB0D6))
        }

        Section("STATUS") {
            StatusRow("Network", "BitLabs")
            StatusRow("App/API Token", if (s.token.isBlank()) "Missing" else "Configured")
            StatusRow("User ID", s.uid.take(13) + "…")
            StatusRow("SDK", s.sdkStatus)
            StatusRow("Offerwall", s.offerwallStatus)
            StatusRow("Survey availability", s.surveyStatus)
            StatusRow("Backend Callback", s.backendStatus)
            StatusRow("Test Mode", "Check Dashboard")
            Text(
                "Test Mode is a Dashboard setting (Apps → your app → Surveys → Test Mode). The app cannot read it, so it never claims it is on.",
                fontSize = 11.sp, color = Color(0xFF7F8FB5)
            )
        }

        Section("CONFIGURATION") {
            OutlinedTextField(
                value = token, onValueChange = { token = it }, singleLine = true,
                label = { Text("BitLabs App/API Token") },
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = backend, onValueChange = { backend = it }, singleLine = true,
                label = { Text("Backend URL (https://…, optional)") }, modifier = Modifier.fillMaxWidth()
            )
            Text("Use the App/API Token from BitLabs Dashboard → Apps → your app → Integration. Not the Secret Key. Not the Unity Ads Game ID.", fontSize = 11.sp, color = Color(0xFF7F8FB5))
            Button({ s.saveConfig(token, backend) }, Modifier.fillMaxWidth()) { Text("Save configuration") }
        }

        Section("1. OFFERWALL") {
            Button({ s.launch(onActivity, null, "Offerwall") }, Modifier.fillMaxWidth()) { Text("Open BitLabs Offerwall") }
        }

        Section("2. OFFERS & GAMES") {
            Button({ s.launch(onActivity, "offers", "Offers") }, Modifier.fillMaxWidth()) { Text("Open Offers") }
            Button({ s.launch(onActivity, "gaming", "Games") }, Modifier.fillMaxWidth()) { Text("Open Games") }
            Text("Games/Offers only show if enabled for your placement in the Dashboard. If none exist, BitLabs shows its own empty state; this app never invents offers.", fontSize = 11.sp, color = Color(0xFF7F8FB5))
        }

        Section("3. SURVEYS") {
            Button({ s.launch(onActivity, "surveys", "Surveys") }, Modifier.fillMaxWidth()) { Text("Open Surveys") }
            OutlinedButton({ s.checkSurveys() }, Modifier.fillMaxWidth()) { Text("Check survey availability") }
        }

        Section("4. COINS") {
            StatusRow("Demo Coins (local, not real)", s.demoCoins.toString())
            StatusRow("Verified balance (server)", s.verifiedBalance ?: "n/a")
            Text("Real rewards are credited only by a signed server-to-server callback on your backend. Nothing here is awarded from client-side SDK events.", fontSize = 11.sp, color = Color(0xFF7F8FB5))
            Button({ s.loadLedger(); go("tx") }, Modifier.fillMaxWidth()) { Text("Transaction history") }
        }

        Section("5. TEST CONTROLS") {
            Button({ s.initSdk() }, Modifier.fillMaxWidth()) { Text("Initialize SDK") }
            OutlinedButton({ s.log(s.statusReport()) }, Modifier.fillMaxWidth()) { Text("Check SDK status") }
            OutlinedButton({ s.checkBackend() }, Modifier.fillMaxWidth()) { Text("Check backend connection") }
            OutlinedButton({ s.resetLocalDemo(); token = s.token; backend = s.backendUrl }, Modifier.fillMaxWidth()) { Text("Reset local demo data") }
        }

        Section("DIAGNOSTIC LOG (token redacted)") {
            if (s.logs.isEmpty()) Text("No events yet.", fontSize = 12.sp, color = Color(0xFF7F8FB5))
            s.logs.take(40).forEach { Text(it, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
        }
    }
}

@Composable
private fun TransactionsScreen(s: AppState, back: () -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Transaction history", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Source: your backend ledger (verified callbacks only). Demo coins never appear here.", fontSize = 12.sp, color = Color(0xFF9FB0D6))
        StatusRow("Verified balance", s.verifiedBalance ?: "n/a")
        Text(s.ledgerMessage, fontSize = 12.sp, color = Warn)
        if (s.ledger.isEmpty()) Text("No verified transactions yet.", fontSize = 13.sp)
        s.ledger.forEach { t ->
            Section(t.status.uppercase() + "  ·  " + t.type) {
                Text("TX: ${t.tx}", fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                Text("Value: ${t.value}   ${t.at}", fontSize = 12.sp)
                if (t.note.isNotBlank()) Text(t.note, fontSize = 11.sp, color = Warn)
            }
        }
        Button({ s.loadLedger() }, Modifier.fillMaxWidth()) { Text("Refresh") }
        OutlinedButton(back, Modifier.fillMaxWidth()) { Text("Back") }
    }
}
