package com.example.bitlabstester

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Tx(val tx: String, val status: String, val type: String, val value: String, val at: String, val note: String)
data class Ledger(val balance: String, val items: List<Tx>)

/** Talks ONLY to your own backend (read-only). No secret keys are used or stored here. */
object Backend {
    private fun get(url: String): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000; c.requestMethod = "GET"
        return try {
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            code to (stream?.bufferedReader()?.use { it.readText() } ?: "")
        } finally { c.disconnect() }
    }

    private fun checkUrl(base: String): String? =
        if (base.isBlank()) "Backend URL not configured." else if (!base.startsWith("https://")) "Backend URL must start with https://" else null

    fun health(base: String): Pair<Boolean, String> {
        checkUrl(base)?.let { return false to it }
        return try {
            val (code, body) = get("$base/health")
            if (code == 200) {
                val j = JSONObject(body)
                val ok = j.optBoolean("ok") && j.optBoolean("secretConfigured")
                ok to (if (ok) "Backend reachable; secret key configured on server." else "Backend reachable but BITLABS_SECRET_KEY is not set on the server.")
            } else false to "Backend returned HTTP $code"
        } catch (t: Throwable) { false to "Backend unreachable: ${t.javaClass.simpleName}: ${t.message}" }
    }

    fun ledger(base: String, uid: String): Pair<Ledger?, String> {
        checkUrl(base)?.let { return null to it }
        return try {
            val (code, body) = get("$base/api/transactions?uid=" + URLEncoder.encode(uid, "UTF-8"))
            if (code != 200) return null to "Backend returned HTTP $code"
            val j = JSONObject(body)
            val arr = j.getJSONArray("transactions")
            val items = (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Tx(o.optString("tx"), o.optString("status"), o.optString("type"), o.optString("val"), o.optString("receivedAt"), o.optString("note"))
            }
            Ledger(j.optString("verifiedBalance", "0"), items) to "Loaded ${items.size} transaction(s)."
        } catch (t: Throwable) { null to "Could not load transactions: ${t.javaClass.simpleName}: ${t.message}" }
    }
}
