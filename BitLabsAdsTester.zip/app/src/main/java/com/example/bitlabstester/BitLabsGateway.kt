package com.example.bitlabstester

import ai.bitlabs.sdk.BitLabs
import android.content.Context

/**
 * ALL calls to the official BitLabs SDK live in this one file.
 * If the SDK package/API differs from what is written here, this is the only file to adjust.
 */
object BitLabsGateway {
    data class Result(val ok: Boolean, val message: String)

    @Volatile var sdkInitialized = false
        private set
    @Volatile var offerwallReady = false
        private set

    fun initialize(token: String, uid: String): Result {
        if (token.isBlank()) {
            sdkInitialized = false; offerwallReady = false
            return Result(false, "App/API Token is missing. Enter it in Configuration.")
        }
        return try {
            BitLabs.API.init(token, uid)
            BitLabs.OFFERWALL.create(token, uid) // fails here if the SDK cannot build an offerwall
            sdkInitialized = true; offerwallReady = true
            Result(true, "SDK initialized (API + Offerwall instance created).")
        } catch (t: Throwable) {
            sdkInitialized = false; offerwallReady = false
            Result(false, "SDK init failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    /** displayMode: null = dashboard default, or "surveys" / "offers" / "gaming" (documented display_mode values). */
    fun launch(context: Context, token: String, uid: String, displayMode: String?): Result {
        if (token.isBlank()) return Result(false, "App/API Token is missing. Enter it in Configuration.")
        return try {
            val offerwall = BitLabs.OFFERWALL.create(token, uid)
            if (displayMode != null) offerwall.options["display_mode"] = displayMode
            offerwall.launch(context)
            offerwallReady = true
            Result(true, "Offerwall launched" + (displayMode?.let { " (display_mode=$it)" } ?: "") + ".")
        } catch (t: Throwable) {
            offerwallReady = false
            Result(false, "Launch failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }

    /** Real survey availability check via BitLabs.API.checkSurveys. Callback may arrive off the main thread. */
    fun checkSurveys(token: String, uid: String, done: (Boolean?, String) -> Unit) {
        if (token.isBlank()) { done(null, "App/API Token is missing."); return }
        try {
            BitLabs.API.init(token, uid)
            BitLabs.API.checkSurveys(
                { hasSurveys -> done(hasSurveys, if (hasSurveys) "Surveys available." else "No surveys available for this user right now.") },
                { e -> done(null, "checkSurveys error: ${e.message}") }
            )
        } catch (t: Throwable) {
            done(null, "checkSurveys failed: ${t.javaClass.simpleName}: ${t.message}")
        }
    }
}
