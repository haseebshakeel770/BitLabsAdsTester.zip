package com.example.bitlabstester

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

class AppState(context: Context) {
    private val prefs = Prefs(context)
    private val main = Handler(Looper.getMainLooper())
    private fun ui(block: () -> Unit) { main.post(block) }

    var token by mutableStateOf(prefs.token)
    var backendUrl by mutableStateOf(prefs.backendUrl)
    val uid: String = prefs.userId

    var sdkStatus by mutableStateOf("Not initialized")
    var offerwallStatus by mutableStateOf("Not Ready")
    var backendStatus by mutableStateOf(if (prefs.backendUrl.isBlank()) "Not Configured" else "Not checked")
    var surveyStatus by mutableStateOf("Not checked")

    /** Local demo counter only. Nothing in this app credits it from client-side SDK events. */
    var demoCoins by mutableStateOf(0)
    var verifiedBalance by mutableStateOf<String?>(null)
    var ledger by mutableStateOf<List<Tx>>(emptyList())
    var ledgerMessage by mutableStateOf("Not loaded. Requires a deployed backend.")

    val logs = mutableStateListOf<String>()

    private fun redact(s: String): String {
        var out = s
        if (token.isNotBlank()) out = out.replace(token, "[token]")
        return out
    }

    fun log(msg: String) {
        val line = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + redact(msg)
        ui { logs.add(0, line); while (logs.size > 100) logs.removeAt(logs.size - 1) }
    }

    fun saveConfig(newToken: String, newBackend: String) {
        prefs.token = newToken; prefs.backendUrl = newBackend
        token = prefs.token; backendUrl = prefs.backendUrl
        sdkStatus = "Not initialized"; offerwallStatus = "Not Ready"
        backendStatus = if (backendUrl.isBlank()) "Not Configured" else "Not checked"
        log("Configuration saved (token " + (if (token.isBlank()) "missing" else "present") + ").")
    }

    fun initSdk() {
        val r = BitLabsGateway.initialize(token, uid)
        sdkStatus = if (r.ok) "Initialized" else "Failed"
        offerwallStatus = if (BitLabsGateway.offerwallReady) "Ready" else "Not Ready"
        log(r.message)
    }

    fun launch(context: Context, mode: String?, label: String) {
        log("Opening $label ...")
        val r = BitLabsGateway.launch(context, token, uid, mode)
        if (r.ok) { sdkStatus = "Initialized" } else { sdkStatus = "Failed" }
        offerwallStatus = if (BitLabsGateway.offerwallReady) "Ready" else "Not Ready"
        log(r.message)
    }

    fun checkSurveys() {
        log("Checking survey availability ...")
        BitLabsGateway.checkSurveys(token, uid) { has, msg ->
            ui { surveyStatus = when (has) { true -> "Available"; false -> "None available"; null -> "Error" } }
            log(msg)
        }
    }

    fun checkBackend() {
        if (backendUrl.isBlank()) { backendStatus = "Not Configured"; log("Backend URL not configured."); return }
        backendStatus = "Checking ..."
        thread {
            val (ok, msg) = Backend.health(backendUrl)
            ui { backendStatus = if (ok) "Connected" else "Unreachable / not ready" }
            log(msg)
        }
    }

    fun loadLedger() {
        ledgerMessage = "Loading ..."
        thread {
            val (l, msg) = Backend.ledger(backendUrl, uid)
            ui {
                ledgerMessage = msg
                if (l != null) { ledger = l.items; verifiedBalance = l.balance }
            }
            log(msg)
        }
    }

    fun resetLocalDemo() {
        demoCoins = 0; verifiedBalance = null; ledger = emptyList()
        ledgerMessage = "Not loaded. Requires a deployed backend."
        surveyStatus = "Not checked"
        logs.clear()
        log("Local demo data reset. (Server-side ledger is not touched; user ID is kept stable.)")
    }

    fun statusReport(): String =
        "SDK=$sdkStatus, Offerwall=$offerwallStatus, Token=" + (if (token.isBlank()) "Missing" else "Configured") +
            ", Backend=$backendStatus, Surveys=$surveyStatus"
}
