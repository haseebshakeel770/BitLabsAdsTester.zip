package com.example.bitlabstester

import android.content.Context
import java.util.UUID

/** Local, app-private settings. The App/API Token is a client-side value (not a secret key). */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("bitlabs_tester", Context.MODE_PRIVATE)

    var token: String
        get() = sp.getString("token", null) ?: BuildConfig.DEFAULT_APP_TOKEN
        set(v) = sp.edit().putString("token", v.trim()).apply()

    var backendUrl: String
        get() = sp.getString("backend", null) ?: BuildConfig.DEFAULT_BACKEND_URL
        set(v) = sp.edit().putString("backend", v.trim().trimEnd('/')).apply()

    /** Stable random test user ID (UUID: no characters BitLabs disallows in uid). */
    val userId: String
        get() {
            val existing = sp.getString("uid", null)
            if (existing != null) return existing
            val fresh = "test-" + UUID.randomUUID().toString()
            sp.edit().putString("uid", fresh).apply()
            return fresh
        }
}
